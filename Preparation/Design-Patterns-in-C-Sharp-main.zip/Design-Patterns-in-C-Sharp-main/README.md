# Code Examples from my Course: Mastering Design Patterns in C#: A Beginner-Friendly Guide, Including OOP and SOLID Principles

- **Full video course**: https://www.youtube.com/watch?v=Rs8PtOmr1qo&list=PLxkN9e3dfloHD01FzTGVYWYgGgtepuQIg

- **eBook course & cheatsheet**: https://doabledanny.gumroad.com/l/ennyj

- **Amazon Kindle & physical book**: https://www.amazon.com/Mastering-Design-Patterns-Beginner-Friendly-Principles/dp/B0DBZGQZMZ
