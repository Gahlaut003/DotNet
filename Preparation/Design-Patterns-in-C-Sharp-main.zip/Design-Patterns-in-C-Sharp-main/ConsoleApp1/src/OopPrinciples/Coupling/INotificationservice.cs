

namespace ConsoleApp1.Coupling
{
    public interface INotificationService
    {
        void SendNotification(string message);
    }
}