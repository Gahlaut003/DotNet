namespace ConsoleApp1.Inheritance
{
  public class Bike : Vehicle
  {
    int NumberOfWheels { get; set; }
  }
}