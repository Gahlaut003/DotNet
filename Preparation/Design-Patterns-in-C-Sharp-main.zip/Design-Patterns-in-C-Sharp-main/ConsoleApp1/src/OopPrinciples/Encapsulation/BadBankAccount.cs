// No encapsulation = free for all! :(
public class BadBankAccount
{
  public decimal balance;
}