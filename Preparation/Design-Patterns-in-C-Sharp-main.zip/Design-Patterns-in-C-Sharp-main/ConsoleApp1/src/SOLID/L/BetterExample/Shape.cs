

namespace ConsoleApp1.SOLID.L.BetterExample
{
public abstract class Shape
{
  public abstract double Area { get; }
}
}