

namespace ConsoleApp1.SOLID.L.BadExample
{
    public abstract class Shape
    {
        public abstract double Area { get; }
    }
}