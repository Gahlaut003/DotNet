
namespace ConsoleApp1.SOLID.D.BetterExample
{
    public interface IEngine
    {
        void Start();
    }
}