
namespace ConsoleApp1.SOLID.D.BadExample
{
    public class Engine
    {
        public void Start()
        {
            System.Console.WriteLine("Engine started.");
        }
    }
}