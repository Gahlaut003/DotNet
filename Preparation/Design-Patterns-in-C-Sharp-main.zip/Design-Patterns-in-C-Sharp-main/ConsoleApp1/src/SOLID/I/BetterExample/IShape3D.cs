
namespace ConsoleApp1.SOLID.I.BetterExample
{
public interface IShape3D
{
    double Area();
    double Volume();
}
}