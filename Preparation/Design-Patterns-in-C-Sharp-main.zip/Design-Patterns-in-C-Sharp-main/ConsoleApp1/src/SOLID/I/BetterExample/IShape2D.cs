
namespace ConsoleApp1.SOLID.I.BetterExample
{
public interface IShape2D
{
    double Area();
}
}