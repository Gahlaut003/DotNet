namespace ConsoleApp1.SOLID.O.BadExample
{
    public enum ShapeType
    {
        Circle,
        Rectangle
    }
}