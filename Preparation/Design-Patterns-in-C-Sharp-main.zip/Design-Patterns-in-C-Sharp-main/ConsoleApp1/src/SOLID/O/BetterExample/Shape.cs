
namespace ConsoleApp1.SOLID.O.BetterExample
{
public abstract class Shape
{
    public abstract double CalculateArea();
}
}