namespace ConsoleApp1.src.DesignPatterns.Structural.Flyweight.GoodExample
{
    public enum CropType
    {
        Potato,
        Carrot,
        Wheat
    }
}