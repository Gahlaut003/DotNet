namespace ConsoleApp1.src.DesignPatterns.Structural.Flyweight.BadExample
{
    public enum CropType
    {
        Potato,
        Carrot,
        Wheat
    }
}