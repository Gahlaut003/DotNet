namespace ConsoleApp1.src.DesignPatterns.Creational.AbstractFactory.BadExample
{
    public enum OperatingSystemType
    {
        Windows,
        Mac
        // In future, we may need to support Linux, Web, Android...
    }
}