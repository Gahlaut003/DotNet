using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConsoleApp1.src.DesignPatterns.Creational.Builder.GoodExample.Components
{
    public class Engine
    {
        // configuration, e.g. speed, model, etc.
    }
}