namespace ConsoleApp1.src.DesignPatterns.Behavioral.Strategy.BadExample
{
    public enum Overlays
    {
        NONE,
        BLACK_AND_WHITE,
        BLUR
    }
}