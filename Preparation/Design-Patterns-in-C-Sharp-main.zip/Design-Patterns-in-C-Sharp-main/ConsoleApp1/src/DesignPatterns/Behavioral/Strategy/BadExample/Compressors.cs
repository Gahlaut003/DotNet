namespace ConsoleApp1.src.DesignPatterns.Behavioral.Strategy.BadExample
{
    public enum Compressors
    {
        MOV,
        MP4,
        WEBM
    }
}