// Originator originator = new Originator("Hi diddly ho neighborinio :)");
// CareTaker careTaker = new CareTaker(originator);

// careTaker.Backup();
// originator.DoSomething();

// careTaker.Backup();
// originator.DoSomething();

// careTaker.Backup();
// careTaker.ShowHistory();

// careTaker.Undo();

// careTaker.Undo();

// careTaker.ShowHistory();