namespace ConsoleApp1.src.DesignPatterns.Behavioral.State.BadExample
{
    public enum DocumentStates
    {
        DRAFT,
        MODERATION,
        PUBLISHED
    }
}