namespace ConsoleApp1.src.DesignPatterns.Behavioral.State.GoodExample
{
    public enum UserRoles
    {
        READER,
        EDITOR,
        ADMIN
    }
}